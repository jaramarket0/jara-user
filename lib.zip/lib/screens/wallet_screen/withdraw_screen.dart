import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:jara_market/screens/wallet_screen/controller/wallet_controller.dart';
import 'package:jara_market/widgets/custom_button.dart';
import 'package:jara_market/widgets/custom_back_header.dart';

class WithdrawScreen extends StatefulWidget {
  const WithdrawScreen({Key? key}) : super(key: key);

  @override
  State<WithdrawScreen> createState() => _WithdrawScreenState();
}

class _WithdrawScreenState extends State<WithdrawScreen> {
  final TextEditingController _amountController = TextEditingController();
  final TextEditingController _remarkController = TextEditingController();
  int? selectedBankId;
  late WalletController controller;

  @override
  void initState() {
    super.initState();
    controller = Get.find<WalletController>();
    controller.fetchBanks();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Column(
          children: [
            const CustomBackHeader(title: 'Withdraw'),
            Expanded(
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text(
                      'Withdraw to Bank',
                      style:
                          TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
                    ),
                    const SizedBox(height: 24),
                    TextField(
                      controller: _amountController,
                      keyboardType: TextInputType.number,
                      decoration: const InputDecoration(
                        labelText: 'Amount',
                        border: OutlineInputBorder(),
                      ),
                    ),
                    const SizedBox(height: 16),
                    Obx(() {
                      return DropdownButtonFormField<int>(
                        value: selectedBankId,
                        items: controller.banks.map((bank) {
                          return DropdownMenuItem<int>(
                            value: bank['id'],
                            child: Text(bank['name'] ?? ''),
                          );
                        }).toList(),
                        onChanged: (value) {
                          setState(() {
                            selectedBankId = value;
                          });
                        },
                        decoration: const InputDecoration(
                          labelText: 'Select Bank',
                          border: OutlineInputBorder(),
                        ),
                      );
                    }),
                    const SizedBox(height: 16),
                    TextField(
                      controller: _remarkController,
                      decoration: const InputDecoration(
                        labelText: 'Remark (optional)',
                        border: OutlineInputBorder(),
                      ),
                    ),
                    const SizedBox(height: 24),
                    CustomButton(
                      text: 'Withdraw',
                      onPressed: () {
                        if (_amountController.text.isNotEmpty &&
                            selectedBankId != null) {
                          int amount = int.parse(_amountController.text);
                          controller.withdrawToBank(
                            amount,
                            selectedBankId!,
                            'NGN',
                            _remarkController.text.isEmpty
                                ? 'Withdraw to bank'
                                : _remarkController.text,
                          );
                        } else {
                          ScaffoldMessenger.of(context).showSnackBar(
                            const SnackBar(
                                content: Text('Please fill all fields')),
                          );
                        }
                      },
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
